create function GET_CRAIOVA_JUCATORI
return number is
total number(2) := 0;
begin
select count(*) into total from jucator where id_echipa = 4;
return total;
end;
/

