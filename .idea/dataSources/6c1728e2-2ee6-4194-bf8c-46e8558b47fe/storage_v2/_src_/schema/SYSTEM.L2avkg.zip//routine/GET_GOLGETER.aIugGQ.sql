create function GET_GOLGETER
return number is
total number(2) := 0;
begin
select count(*) into total from gol where rownum between 1 and 1;
return total;
end;
/

