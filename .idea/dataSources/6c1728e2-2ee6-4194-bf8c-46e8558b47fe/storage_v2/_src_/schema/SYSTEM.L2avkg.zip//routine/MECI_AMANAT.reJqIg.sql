create procedure "MECI_AMANAT"
(id_meu IN NUMBER,
data_amanata IN NUMBER)
is
begin
update meci set data = data + data_amanata where meci.id = id_meu;
end;
/

