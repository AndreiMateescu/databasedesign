create procedure "ADAUGA_BUGET"
(id_meu IN NUMBER,
valoare IN NUMBER)
is 
begin
update ECHIPA set echipa.buget = echipa.buget + valoare where id = id_meu;
end;
/

