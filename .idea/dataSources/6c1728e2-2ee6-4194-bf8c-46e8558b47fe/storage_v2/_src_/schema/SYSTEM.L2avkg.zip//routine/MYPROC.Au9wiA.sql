create PROCEDURE MyProc
IS
BEGIN
    SELECT * from (SELECT 
         JUCATOR.NUME, JUCATOR.PRENUME, COUNT(*) Nr_Goluri
    FROM GOL g
        INNER JOIN JUCATOR j
    ON g.id_jucator = jucator.cod 
    GROUP BY ID_JUCATOR, JUCATOR.NUME, JUCATOR.PRENUME
    order by Nr_Goluri desc) WHERE ROWNUM = 1
END MyProc

  /

