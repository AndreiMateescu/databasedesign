create PROCEDURE golgeter
IS
BEGIN
SELECT * from (SELECT 
     JUCATOR.NUME, JUCATOR.PRENUME, COUNT(*) Nr_Goluri
FROM GOL 
    INNER JOIN JUCATOR ON gol.id_jucator = jucator.cod 
GROUP BY ID_JUCATOR, JUCATOR.NUME, JUCATOR.PRENUME
order by Nr_Goluri desc)
END;
/

